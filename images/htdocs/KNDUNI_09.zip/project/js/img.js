
const image_1 = document.getElementById("image");

image_1.addEventListener("click", function() {
    image_1.classList.toggle("highlighted");
});
